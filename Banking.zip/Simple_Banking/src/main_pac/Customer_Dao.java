package main_pac;

import java.util.ArrayList;

public class Customer_Dao {

	private static ArrayList<Customer> list = new ArrayList<>();
	
	public void add_new_customer(Customer c) {
		list.add(c);
		System.out.println("Customer added");
	}

	public ArrayList<Customer> fetchCustomer() {
		return list;
	}

	public ArrayList<Customer> getByAccNo(long l) {
		return list;
	}

	public ArrayList<Customer> getByFName(String name) {
		return list;
	}

	public ArrayList<Customer> getByLName(String name) {
		return list;
	}
	
	

}
