package main_pac;

import java.util.ArrayList;
import java.util.Scanner;

public class Bank {

	private static final String Yes = "yes";
	private static final String no = "no";
	static private Services s = new Services();

	private static void Add_Customer() {
//		Customer c1 = new Customer();
//		c1.setAccNo(1234l);
//		c1.setC_FName("Yogesh");
//		c1.setC_LName("Kotkar");
//		c1.setAccType(Account_Type.SAVING_ACCOUNT);
//
//		Customer c2 = new Customer();
//		c2.setAccNo(9009l);
//		c2.setC_FName("Omkar");
//		c2.setC_LName("Parab");
//		c2.setAccType(Account_Type.CURRENT_ACCOUNT);
//
//		Customer c3 = new Customer();
//		c3.setAccNo(2006l);
//		c3.setC_FName("Saurabh");
//		c3.setC_LName("Desai");
//		c3.setAccType(Account_Type.CURRENT_ACCOUNT);
//
//		s.add_new_customer(c1);
//		s.add_new_customer(c2);
//		s.add_new_customer(c3);
	}

	private static void getall_Customers() {
		ArrayList<Customer> list = s.fetchCustomer();
		list.forEach(x -> System.out.println(x));
	}

	private static void getByLName(String string) {
		Customer c = s.getByLName(string);
		System.out.println(c);
	}

	private static void getByAccNo(long l) {
		Customer c = s.getByAccNo(l);
		System.out.println(c);
	}

	private static void getByFName(String string) {
		Customer c = s.getByFName(string);
		System.out.println(c);
	}

	private static void balanceenquiry() {
		Scanner sc = new Scanner(System.in);
		Customer c = new Customer();
		System.out.println("Your Current Balance is : " + c.Current_Balance);
	}

	private static void withdrawalmoney(double amount) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter an amount to withdrawal from Account 1: ");
		double withdrawalAmount = sc.nextDouble();
		Customer c = new Customer();
		c.Current_Balance = c.Current_Balance - amount;
		System.out.println("Your Current Balance is : " + c.Current_Balance);
	}

	private static void depositmoney(double amount) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter an amount to deposit into Account : ");
		double depositAmount = sc.nextDouble();
		Customer c = new Customer();
		c.Current_Balance = c.Current_Balance + amount;
		System.out.println("Your Current Balance is: " + c.Current_Balance);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome");
		Customer c = new Customer();
		System.out.print("Enter Account no: ");
		Long accno = sc.nextLong();
		c.setAccNo(accno);

		System.out.print("Enter First Name: ");
		String fname = sc.next();
		c.setC_FName(fname);

		System.out.print("Enter Last Name: ");
		String lname = sc.next();
		c.setC_LName(lname);

		c.setAccType(Account_Type.CURRENT_ACCOUNT);

		s.add_new_customer(c);

		System.out.println("1.Deposit Money.");
		System.out.println("2.Withdrawal Money.");
		System.out.println("3.Balance Enquiry.");

		int choice = sc.nextInt();

		double amount = 0;
		switch (choice) {
		case 1:
			depositmoney(amount);
			break;

		case 2:
			withdrawalmoney(amount);
			break;

		case 3:
			balanceenquiry();
			break;

		default:
			System.out.println("Invalid Input.");
			break;
		}

		System.out.println("Do u want to Continue:Yes/No");
		String ans = sc.next().toLowerCase();

		Add_Customer();
		getall_Customers();

	}
}
