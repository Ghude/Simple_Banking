package main_pac;

public class Customer {
	private String c_FName;
	private String c_LName;
	private Long accNo;
	private Account_Type accType;
	protected Double Current_Balance=0.0;

	public Customer() {
		super();
	}

	public Customer(String c_FName, String c_LName, Long accNo, Account_Type accType, Double current_Balance) {
		super();
		this.c_FName = c_FName;
		this.c_LName = c_LName;
		this.accNo = accNo;
		this.accType = accType;
		Current_Balance = current_Balance;
	}

	public String getC_FName() {
		return c_FName;
	}

	public void setC_FName(String c_FName) {
		this.c_FName = c_FName;
	}

	public String getC_LName() {
		return c_LName;
	}

	public void setC_LName(String c_LName) {
		this.c_LName = c_LName;
	}

	public Long getAccNo() {
		return accNo;
	}

	public void setAccNo(Long accNo) {
		this.accNo = accNo;
	}

	public Account_Type getAccType() {
		return accType;
	}

	public void setAccType(Account_Type accType) {
		this.accType = accType;
	}

	public Double getCurrent_Balance() {
		return Current_Balance;
	}

	public void setCurrent_Balance(Double current_Balance) {
		Current_Balance = current_Balance;
	}

	@Override
	public String toString() {
		return "Customer [c_FName=" + c_FName + ", c_LName=" + c_LName + ", accNo=" + accNo + ", accType=" + accType
				+ ", Current_Balance=" + Current_Balance + "]";
	}

}
