package main_pac;

public enum Account_Type {
SAVING_ACCOUNT,
CURRENT_ACCOUNT,
}
