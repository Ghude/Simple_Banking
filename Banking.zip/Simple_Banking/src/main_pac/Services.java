package main_pac;

import java.util.ArrayList;

public class Services {
	
	private Customer_Dao cd = new Customer_Dao();
	
	public void add_new_customer(Customer c) {
		if(c!=null) {
			cd.add_new_customer(c);
		}
		else {
			System.out.println("Enter Valid Detail's.");
		}
	}
	
	public ArrayList<Customer> fetchCustomer() {
		ArrayList<Customer> list = cd.fetchCustomer();
		if (list == null) {
			System.out.println("No Customer.");
		}
		return list;
	}

	public Customer getByFName(String name) {
		ArrayList<Customer> list = cd.getByFName(name);

		Customer c = null;
		for (Customer customer : list) {
			if (customer.getC_FName().equals(name))
				c = customer;
		}

		return c;
	}
	
	public Customer getByLName(String name) {
		ArrayList<Customer> list = cd.getByLName(name);

		Customer c = null;
		for (Customer customer : list) {
			if (customer.getC_LName().equals(name))
				c = customer;
		}

		return c;
	}

	public Customer getByAccNo(long l) {
		ArrayList<Customer> list = cd.getByAccNo(l);
		Customer c = null;
		for (Customer customer : list) {
			if (customer.getAccNo().equals(l))
				c = customer;
		}

		return c;
	}

}
